#ifndef PHP_DBM_H
#define PHP_DBM_H

#if DBA_DBM

#include "php_dba.h"

DBA_FUNCS(dbm);

#endif

#endif
